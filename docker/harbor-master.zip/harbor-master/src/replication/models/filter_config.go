package models

//FilterConfig is data model to provide configurations to the filters.
type FilterConfig struct {
	//The pattern for fuzzy matching
	Pattern string
}

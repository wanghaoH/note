complete -W $(harbor bash-completion) harbor
